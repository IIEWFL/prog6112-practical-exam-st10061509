package st10061509_bcad1_exam.Question1;

public class App {
    public static void main(String[] args) {
        // Movie titles
        String[] movieTitles = {"Napoleon", "Oppenheimer"};
        
        // Sales data for each movie: rows represent movies, columns represent months (Jan, Feb, Mar)
        int[][] salesData = {
            {3000, 1500, 1700}, // Napoleon sales
            {3500, 1200, 1600}  // Oppenheimer sales
        };

        // Generate and display the sales report
        SalesReport report = new SalesReport(movieTitles, salesData);
        report.displayReport();
    }
}

class SalesReport {
    private String[] movieTitles;
    private int[][] salesData;

    public SalesReport(String[] movieTitles, int[][] salesData) {
        this.movieTitles = movieTitles;
        this.salesData = salesData;
    }

    public void displayReport() {
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println("==================================");
        System.out.printf("%-15s %-10s %-10s %-10s%n", "", "Jan", "Feb", "Mar");
        System.out.println("------------------------------------------------");

        int[] totalSales = new int[movieTitles.length];

        // Display sales data and calculate total sales
        for (int i = 0; i < movieTitles.length; i++) {
            System.out.printf("%-15s ", movieTitles[i]);
            for (int j = 0; j < salesData[i].length; j++) {
                System.out.printf("%-10d ", salesData[i][j]);
                totalSales[i] += salesData[i][j]; // Calculate total sales for each movie
            }
            System.out.println();
        }

        // Display total sales for each movie
        for (int i = 0; i < movieTitles.length; i++) {
            System.out.printf("Total movie ticket sales for %s: %d%n", movieTitles[i], totalSales[i]);
        }

        // Determine the top performing movie
        int maxSalesIndex = 0;
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[maxSalesIndex]) {
                maxSalesIndex = i;
            }
        }
        System.out.printf("Top performing movie: %s%n", movieTitles[maxSalesIndex]);
    }
}

