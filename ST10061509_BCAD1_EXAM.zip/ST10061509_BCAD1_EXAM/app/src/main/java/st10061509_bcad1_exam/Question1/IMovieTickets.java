package st10061509_bcad1_exam.Question1;

public interface IMovieTickets {
    /**
     * Method to calculate the total movie sales.
     * @param movieTicketSales an array of integers representing ticket sales for each movie.
     * @return total sales amount as an integer.
     */
    int TotalMovieSales(int[] movieTicketSales);

    /**
     * Method to get the name of the top movie based on sales.
     * @param movies an array of strings representing movie names.
     * @param totalSales an array of integers representing total sales for each movie.
     * @return the name of the top movie as a String.
     */
    String TopMovie(String[] movies, int[] totalSales);
}
