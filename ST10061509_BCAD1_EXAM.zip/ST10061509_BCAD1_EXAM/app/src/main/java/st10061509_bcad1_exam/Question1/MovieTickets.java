package st10061509_bcad1_exam.Question1;

public class MovieTickets implements IMovieTickets {

    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int totalSales = 0;
        for (int sales : movieTicketSales) {
            totalSales += sales; // Sum up all ticket sales
        }
        return totalSales; // Return the total sales
    }

    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        if (movies.length == 0 || totalSales.length == 0) {
            return "No movies available"; // Handle empty input
        }

        int maxSalesIndex = 0; // Index of the top movie
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[maxSalesIndex]) {
                maxSalesIndex = i; // Update index if current sales are higher
            }
        }
        return movies[maxSalesIndex]; // Return the name of the top movie
    }

    public static void main(String[] args) {
        MovieTickets movieTickets = new MovieTickets();

        // Sample data
        String[] movies = {"Oppenheimer", "Napoleon", "Barbie"};
        int[] sales = {150, 200, 300};

        // Calculate total sales
        int totalSales = movieTickets.TotalMovieSales(sales);
        System.out.println("Total Movie Sales: " + totalSales);

        // Get the top movie
        String topMovie = movieTickets.TopMovie(movies, sales);
        System.out.println("Top Movie: " + topMovie);
    }
}
