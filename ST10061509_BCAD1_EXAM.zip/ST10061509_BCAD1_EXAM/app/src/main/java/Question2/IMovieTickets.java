package Question2;

public interface IMovieTickets {
    /**
     * Calculates the total ticket price based on the ticket price and number of
     * tickets.
     * 
     * @return the total ticket price.
     */
    double calculateTotalTicketPrice();

    /**
     * Validates the data for the movie ticket.
     * 
     * @return true if the data is valid, false otherwise.
     */
    boolean validateData();
}