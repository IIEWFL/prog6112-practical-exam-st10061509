package Question2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class MovieTicketSalesApp extends JFrame {
    private JComboBox<String> movieComboBox;
    private JTextField ticketCountField;
    private JTextField ticketPriceField;
    private JTextArea reportArea;

    public MovieTicketSalesApp() {
        // Set up the frame
        setTitle("Movie Ticket Sales");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(0, 1)); // Use GridLayout to stack components vertically

        // Create combo box for movie selection
        String[] movies = {"Napoleon", "Oppenheimer", "Damsel"};
        movieComboBox = new JComboBox<>(movies);

        // Create text fields for ticket count and ticket price
        ticketCountField = new JTextField(10);
        ticketPriceField = new JTextField(10);

        // Create text area for displaying the report
        reportArea = new JTextArea(5, 30); // Set rows and columns for text area
        reportArea.setEditable(false); // Make it read-only
        JScrollPane scrollPane = new JScrollPane(reportArea);

        // Create button to submit input
        JButton submitButton = new JButton("Process");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateReport();
            }
        });

        // Create clear button
        JButton clearButton = new JButton("Clear Fields");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields(); // Call method to clear fields
            }
        });

        // Create save report button
        JButton saveButton = new JButton("Save Report");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveReportToFile();
            }
        });

        // Create exit button
        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Exit the application
            }
        });

        // Add components to the frame
        add(new JLabel("Select Movie:"));
        add(movieComboBox);
        add(new JLabel("Number of Tickets:"));
        add(ticketCountField);
        add(new JLabel("Ticket Price:"));
        add(ticketPriceField);
        add(submitButton);
        add(clearButton); // Add the clear button to the frame
        add(scrollPane);
        add(saveButton); // Add the save report button to the frame
        add(exitButton); // Add the exit button to the frame
    }

    private void generateReport() {
        String selectedMovie = (String) movieComboBox.getSelectedItem();
        int ticketCount;
        double ticketPrice;

        // Validate input
        try {
            ticketCount = Integer.parseInt(ticketCountField.getText());
            ticketPrice = Double.parseDouble(ticketPriceField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for tickets and price.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Calculate total price and VAT
        double totalPrice = ticketCount * ticketPrice;
        double vatAmount = totalPrice * 0.2; // Assuming VAT is 20%
        double totalWithVAT = totalPrice + vatAmount;

        // Generate report
        String report = "Movie: " + selectedMovie + "\n" +
                        "Tickets Sold: " + ticketCount + "\n" +
                        "Ticket Price: R" + String.format("%.2f", ticketPrice) + "\n" +
                        "Total Price: R" + String.format("%.2f", totalPrice) + "\n" +
                        "VAT Amount (14%): R" + String.format("%.2f", vatAmount) + "\n" +
                        "Total Price with VAT: R" + String.format("%.2f", totalWithVAT) + "\n";
        
        reportArea.setText(report); // Update the JTextArea with the report
    }

    private void clearFields() {
        // Clear the text fields and reset the combo box
        ticketCountField.setText("");
        ticketPriceField.setText("");
        movieComboBox.setSelectedIndex(0); // Reset to the first movie
        reportArea.setText(""); // Clear the report area
    }

    private void saveReportToFile() {
        String report = reportArea.getText();
        if (report.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No report to save. Please generate a report first.", "Save Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
            writer.write(report);
            JOptionPane.showMessageDialog(this, "Report saved to report.txt", "Save Successful", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving report: " + e.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MovieTicketSalesApp app = new MovieTicketSalesApp();
            app.setVisible(true);
        });
    }
}


