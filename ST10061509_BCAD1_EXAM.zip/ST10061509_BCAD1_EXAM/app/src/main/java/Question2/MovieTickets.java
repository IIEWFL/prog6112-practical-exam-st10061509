package Question2;



public class MovieTickets implements IMovieTickets {
    // Attributes
    private String name; // Name of the movie
    private double price; // Price of the ticket
    private int number;   // Number of tickets

    // Constructor
    public MovieTickets(String name, double price, int number) {
        if (validateName(name) && validatePrice(price) && validateNumber(number)) {
            this.name = name;
            this.price = price;
            this.number = number;
        } else {
            throw new IllegalArgumentException("Invalid data provided for movie ticket.");
        }
    }

    
    // Method to validate the movie ticket name
    private boolean validateName(String name) {
        return name != null && !name.trim().isEmpty();
    }

    // Method to validate the movie ticket price
    private boolean validatePrice(double price) {
        return price > 0;
    }

    // Method to validate the number of movie tickets
    private boolean validateNumber(int number) {
        return number > 0;
    }

    // Implementing the calculateTotalTicketPrice method from IMovieTickets
    @Override
    public double calculateTotalTicketPrice() {
        return price * number;
    }

    // Implementing the validateData method from IMovieTickets
    @Override
    public boolean validateData() {
        return validateName(name) && validatePrice(price) && validateNumber(number);
    }

    // Getters
    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getNumber() {
        return number;
    }
}
