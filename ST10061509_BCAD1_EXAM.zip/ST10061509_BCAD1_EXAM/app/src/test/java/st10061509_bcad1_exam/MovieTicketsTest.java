package st10061509_bcad1_exam;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import st10061509_bcad1_exam.Question1.MovieTickets;

public class MovieTicketsTest {

    private MovieTickets movieTickets;

    @BeforeEach
    public void setUp() {
        // Initialize the MovieTickets object before each test
        movieTickets = new MovieTickets();
    }

    @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
        // Arrange: Sample movie ticket sales
        int[] sales = {150, 200, 300};

        // Act: Call the TotalMovieSales method
        int totalSales = movieTickets.TotalMovieSales(sales);

        // Assert: Verify the total sales
        assertEquals(650, totalSales, "Total movie sales should be 650");
    }

    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        // Arrange: Sample movie names and their corresponding sales
        String[] movies = {"Oppenheimer", "Napoleon", "Barbie"};
        int[] sales = {150, 200, 300};

        // Act: Call the TopMovie method
        String topMovie = movieTickets.TopMovie(movies, sales);

        // Assert: Verify the top movie
        assertEquals("Barbie", topMovie, "Top movie should be Barbie");
    }
}
