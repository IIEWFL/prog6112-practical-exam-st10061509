package st10061509_bcad1_exam.Question2Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MovieTicketsTest {

    @Test
    public void testCalculateTotalTicketPrice_CalculatedSuccessfully() {
        MovieTickets ticket = new MovieTickets("Inception", 3, 10.0);
        double totalPrice = ticket.calculateTotalTicketPrice();
        assertEquals(30.0, totalPrice, "Total ticket price should be 30.0");
    }

    @Test
    public void testCalculateTotalTicketPrice_InvalidInput_ThrowsException() {
        MovieTickets ticket = new MovieTickets("Inception", -1, 10.0);
        assertThrows(IllegalArgumentException.class, ticket::calculateTotalTicketPrice);
    }

    @Test
    public void testValidMovieName() {
        MovieTickets ticket = new MovieTickets("Inception", 2, 10.0);
        assertTrue(ticket.isValidMovieName(), "Movie name should be valid");
    }

    @Test
    public void testInvalidMovieName() {
        MovieTickets ticket = new MovieTickets("", 2, 10.0);
        assertFalse(ticket.isValidMovieName(), "Movie name should be invalid");
    }

    @Test
    public void testValidNumberOfTickets() {
        MovieTickets ticket = new MovieTickets("Inception", 2, 10.0);
        assertTrue(ticket.isValidNumberOfTickets(), "Number of tickets should be valid");
    }

    @Test
    public void testInvalidNumberOfTickets() {
        MovieTickets ticket = new MovieTickets("Inception", 0, 10.0);
        assertFalse(ticket.isValidNumberOfTickets(), "Number of tickets should be invalid");
    }

    @Test
    public void testValidTicketPrice() {
        MovieTickets ticket = new MovieTickets("Inception", 2, 10.0);
        assertTrue(ticket.isValidTicketPrice(), "Ticket price should be valid");
    }

    @Test
    public void testInvalidTicketPrice() {
        MovieTickets ticket = new MovieTickets("Inception", 2, -5.0);
        assertFalse(ticket.isValidTicketPrice(), "Ticket price should be invalid");
    }
}
